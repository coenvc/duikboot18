package shared;

public interface IFonds {

	String getNaam();

	double getKoers();

}